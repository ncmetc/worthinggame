
import React, { useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Map, MapPin, Compass, Award } from 'lucide-react';

const Index = () => {
  const parallaxRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleScroll = () => {
      if (!parallaxRef.current) return;
      const scrollY = window.scrollY;
      parallaxRef.current.style.transform = `translateY(${scrollY * 0.3}px)`;
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero section with pier image */}
      <section className="relative h-screen flex items-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-coast-500/40 to-coast-700/60 z-10"></div>
        
        {/* Background image with parallax effect - using pier image */}
        <div ref={parallaxRef} className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-[url('/lovable-uploads/d76012b7-61e0-47b2-abe9-17c18fb023c8.png')] bg-cover bg-center"></div>
        </div>
        
        <div className="container mx-auto px-4 md:px-6 relative z-20">
          <div className="max-w-3xl mx-auto text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6 leading-tight">
                Discover Worthing&apos;s Hidden Stories
              </h1>
              <p className="text-lg md:text-xl text-white/90 mb-8">
                An interactive adventure through the seaside town of Worthing. Complete challenges, discover landmarks, and uncover local history.
              </p>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <Link
                  to="/explore"
                  className="w-full sm:w-auto px-8 py-3 bg-coast-600 hover:bg-coast-700 text-white font-medium rounded-lg transition-colors duration-300 flex items-center justify-center"
                >
                  Start Exploring
                  <Compass className="ml-2 h-5 w-5" />
                </Link>
                <Link
                  to="/challenges"
                  className="w-full sm:w-auto px-8 py-3 bg-white hover:bg-coast-50 text-coast-700 font-medium rounded-lg transition-colors duration-300 flex items-center justify-center"
                >
                  View Challenges
                  <Award className="ml-2 h-5 w-5" />
                </Link>
              </div>
            </motion.div>
          </div>
        </div>
        
        {/* Scroll indicator */}
        <motion.div
          className="absolute bottom-10 left-1/2 transform -translate-x-1/2 z-20"
          animate={{ y: [0, 10, 0] }}
          transition={{ repeat: Infinity, duration: 2 }}
        >
          <div className="w-8 h-12 rounded-full border-2 border-white/50 flex items-center justify-center">
            <div className="w-2 h-2 rounded-full bg-white animate-pulse-gentle"></div>
          </div>
        </motion.div>
      </section>
      
      {/* Features section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-coast-900 mb-4">How It Works</h2>
            <p className="text-lg text-coast-700 max-w-2xl mx-auto">
              Embark on an interactive journey through Worthing&apos;s landmarks and hidden gems.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                icon: <Map className="w-12 h-12 text-coast-600" />,
                title: 'Explore the Map',
                description: 'Navigate through an interactive map of Worthing. Discover key landmarks and hidden locations as you explore.'
              },
              {
                icon: <Award className="w-12 h-12 text-sand-500" />,
                title: 'Complete Challenges',
                description: 'Test your knowledge and observation skills with location-based challenges. Earn achievements as you progress.'
              },
              {
                icon: <MapPin className="w-12 h-12 text-pier-700" />,
                title: 'Discover History',
                description: 'Learn about Worthing&apos;s rich history and culture. Uncover stories and facts about the town&apos;s significant landmarks.'
              }
            ].map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="flex flex-col items-center text-center p-6 bg-coast-50 rounded-2xl border border-coast-100 hover:shadow-lg transition-shadow duration-300"
              >
                <div className="mb-4 p-3 bg-white rounded-full shadow-sm">
                  {feature.icon}
                </div>
                <h3 className="text-xl font-semibold text-coast-900 mb-2">{feature.title}</h3>
                <p className="text-coast-700">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
      
      {/* Getting started section with pier image */}
      <section className="py-20 bg-coast-50">
        <div className="container mx-auto px-4 md:px-6">
          <div className="flex flex-col md:flex-row items-center gap-12">
            <div className="md:w-1/2">
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
              >
                <h2 className="text-3xl md:text-4xl font-bold text-coast-900 mb-6">Ready to Begin Your Adventure?</h2>
                <p className="text-lg text-coast-700 mb-6">
                  The Worthing Adventure Game is perfect for tourists, locals, families, and anyone looking to explore the town in a new and exciting way.
                </p>
                <ul className="space-y-4 mb-8">
                  {[
                    'Explore at your own pace - no time limits',
                    'Suitable for all ages and abilities',
                    'Learn fascinating facts about Worthing',
                    'Perfect for sunny days by the seaside'
                  ].map((item, index) => (
                    <li key={index} className="flex items-start">
                      <div className="mr-3 mt-1 w-5 h-5 rounded-full bg-coast-500 flex items-center justify-center">
                        <svg className="w-3 h-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7" />
                        </svg>
                      </div>
                      <span className="text-coast-800">{item}</span>
                    </li>
                  ))}
                </ul>
                <Link
                  to="/explore"
                  className="inline-flex items-center px-6 py-3 bg-coast-600 hover:bg-coast-700 text-white font-medium rounded-lg transition-colors duration-300"
                >
                  Start your journey
                  <svg className="ml-2 w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 5l7 7m0 0l-7 7m7-7H3" />
                  </svg>
                </Link>
              </motion.div>
            </div>
            <div className="md:w-1/2">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.2 }}
                className="relative rounded-2xl overflow-hidden shadow-xl"
              >
                <img
                  src="/lovable-uploads/d76012b7-61e0-47b2-abe9-17c18fb023c8.png"
                  alt="Worthing Pier"
                  className="w-full h-auto"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent flex items-end">
                  <div className="p-6">
                    <span className="px-3 py-1 bg-white/20 backdrop-blur-sm text-white text-sm rounded-full mb-2 inline-block">
                      Interactive Experience
                    </span>
                    <h3 className="text-2xl font-bold text-white">Explore Worthing Pier</h3>
                  </div>
                </div>
              </motion.div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Index;
