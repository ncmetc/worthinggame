
import React, { useState } from 'react';
import Layout from '@/components/Layout';
import PageHeader from '@/components/PageHeader';
import SearchAndFilter from '@/components/SearchAndFilter';
import ChallengeGrid from '@/components/ChallengeGrid';
import ProgressSection from '@/components/ProgressSection';

const challenges = [
  {
    id: 'c1',
    title: 'Pier Puzzle Trail',
    description: 'Follow the clues along Worthing Pier to uncover a historical secret about this iconic landmark.',
    location: 'Worthing Pier',
    difficulty: 'easy' as const,
    duration: '30-45 min',
    image: '/placeholder.svg',
    completed: true,
    progress: 100,
  },
  {
    id: 'c2',
    title: 'Museum Mystery',
    description: 'Examine the exhibits at Worthing Museum & Art Gallery to solve a challenging puzzle.',
    location: 'Worthing Museum',
    difficulty: 'medium' as const,
    duration: '45-60 min',
    image: '/placeholder.svg',
    completed: false,
    progress: 60,
  },
  {
    id: 'c3',
    title: 'Town Hall Secrets',
    description: 'Discover the architectural details of Worthing Town Hall through this observational challenge.',
    location: 'Town Hall',
    difficulty: 'medium' as const,
    duration: '30-45 min',
    image: '/placeholder.svg',
    completed: false,
    progress: 0,
  },
  {
    id: 'c4',
    title: 'Cinema Heritage Trail',
    description: 'Explore the history of The Dome Cinema, one of Britain\'s oldest cinemas.',
    location: 'The Dome Cinema',
    difficulty: 'easy' as const,
    duration: '30 min',
    image: '/placeholder.svg',
    completed: false,
    progress: 25,
  },
  {
    id: 'c5',
    title: 'Seafront Scavenger Hunt',
    description: 'Find hidden items and landmarks along Worthing\'s beautiful seafront promenade.',
    location: 'Seafront',
    difficulty: 'easy' as const,
    duration: '60 min',
    image: '/placeholder.svg',
    completed: false,
    progress: 0,
  },
  {
    id: 'c6',
    title: 'Worthing\'s Literary Legacy',
    description: 'Trace the footsteps of famous authors who lived and worked in Worthing.',
    location: 'Various Locations',
    difficulty: 'hard' as const,
    duration: '90 min',
    image: '/placeholder.svg',
    completed: false,
    progress: 0,
  },
];

const Challenges = () => {
  const [filter, setFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [isFilterOpen, setIsFilterOpen] = useState(false);

  const filteredChallenges = challenges.filter((challenge) => {
    const matchesFilter = 
      filter === 'all' || 
      (filter === 'completed' && challenge.completed) || 
      (filter === 'in-progress' && !challenge.completed && challenge.progress > 0) || 
      (filter === 'not-started' && challenge.progress === 0);
    
    const matchesSearch = 
      challenge.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
      challenge.location.toLowerCase().includes(searchTerm.toLowerCase());
    
    return matchesFilter && matchesSearch;
  });

  const completedChallenges = challenges.filter(c => c.completed).length;

  return (
    <Layout>
      <div className="pt-20 min-h-screen">
        <div className="container mx-auto px-4 md:px-6 py-8">
          <PageHeader
            title="Worthing Adventure Challenges"
            subtitle="Challenges & Quests"
            description="Complete these interactive challenges to earn achievements and discover Worthing's history and culture."
          />
          
          <SearchAndFilter
            searchTerm={searchTerm}
            setSearchTerm={setSearchTerm}
            filter={filter}
            setFilter={setFilter}
            isFilterOpen={isFilterOpen}
            setIsFilterOpen={setIsFilterOpen}
          />
          
          <ChallengeGrid
            challenges={filteredChallenges}
            searchTerm={searchTerm}
            setSearchTerm={setSearchTerm}
            filter={filter}
            setFilter={setFilter}
          />
          
          <ProgressSection
            totalChallenges={challenges.length}
            completedChallenges={completedChallenges}
          />
        </div>
      </div>
    </Layout>
  );
};

export default Challenges;
