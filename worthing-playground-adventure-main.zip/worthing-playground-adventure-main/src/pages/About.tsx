
import React from 'react';
import Layout from '@/components/Layout';
import { motion } from 'framer-motion';
import { Info, MapPin, Compass, Award, Mail, Phone, MessageSquare } from 'lucide-react';

const About = () => {
  return (
    <Layout>
      <div className="pt-20 min-h-screen">
        <div className="container mx-auto px-4 md:px-6 py-8">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="max-w-3xl mx-auto text-center mb-12"
          >
            <div className="inline-flex items-center justify-center bg-pier-100 text-pier-800 rounded-full px-3 py-1 text-sm font-medium mb-4">
              <Info className="mr-1 h-4 w-4" />
              About the Game
            </div>
            <h1 className="text-3xl md:text-4xl font-bold text-coast-900 mb-4">Discover Worthing Adventure</h1>
            <p className="text-lg text-coast-700">
              Learn about our interactive experience that brings Worthing&apos;s rich history and culture to life.
            </p>
          </motion.div>
          
          {/* About the Game */}
          <section className="mb-16">
            <div className="bg-white rounded-2xl shadow-md overflow-hidden">
              <div className="md:flex">
                <div className="md:w-1/2">
                  <img
                    src="/lovable-uploads/d76012b7-61e0-47b2-abe9-17c18fb023c8.png"
                    alt="Worthing Pier at dusk with flags and amusements sign"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="md:w-1/2 p-6 md:p-8">
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: 0.2 }}
                  >
                    <h2 className="text-2xl font-bold text-coast-900 mb-4">The Worthing Adventure</h2>
                    <p className="text-coast-700 mb-4">
                      The Worthing Adventure is an interactive exploration game designed to help visitors and locals discover the hidden gems, fascinating history, and cultural significance of Worthing, West Sussex.
                    </p>
                    <p className="text-coast-700 mb-6">
                      Our game combines digital technology with real-world exploration, encouraging players to visit locations throughout Worthing&apos;s town center and iconic pier while completing challenges, solving puzzles, and learning about this beautiful seaside town.
                    </p>
                    <div className="grid grid-cols-2 gap-4">
                      {[
                        { icon: <MapPin className="h-5 w-5" />, text: 'Location-based gameplay' },
                        { icon: <Compass className="h-5 w-5" />, text: 'Interactive map exploration' },
                        { icon: <Award className="h-5 w-5" />, text: 'Achievement system' },
                        { icon: <Info className="h-5 w-5" />, text: 'Historical information' }
                      ].map((feature, index) => (
                        <div key={index} className="flex items-center">
                          <div className="w-8 h-8 rounded-full bg-coast-100 flex items-center justify-center mr-3 text-coast-700">
                            {feature.icon}
                          </div>
                          <span className="text-sm text-coast-800">{feature.text}</span>
                        </div>
                      ))}
                    </div>
                  </motion.div>
                </div>
              </div>
            </div>
          </section>
          
          {/* How to Play */}
          <section className="mb-16">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
            >
              <h2 className="text-2xl font-bold text-coast-900 mb-6">How to Play</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {[
                  {
                    step: 1,
                    title: 'Explore the Map',
                    description: 'Use the interactive map to navigate around Worthing. Discover marked locations and find hidden spots throughout the town.'
                  },
                  {
                    step: 2,
                    title: 'Complete Challenges',
                    description: 'At various locations, you&apos;ll find challenges to complete. These might be puzzles, quizzes, or observational tasks related to your surroundings.'
                  },
                  {
                    step: 3,
                    title: 'Collect Achievements',
                    description: 'As you complete challenges and discover locations, you&apos;ll earn achievements. Try to collect them all to complete your Worthing adventure!'
                  }
                ].map((item) => (
                  <div key={item.step} className="bg-white rounded-xl shadow-sm border border-coast-100 p-6 flex flex-col">
                    <div className="mb-4">
                      <div className="w-10 h-10 rounded-full bg-coast-600 text-white flex items-center justify-center font-semibold text-lg">
                        {item.step}
                      </div>
                    </div>
                    <h3 className="text-xl font-semibold text-coast-900 mb-2">{item.title}</h3>
                    <p className="text-coast-700 text-sm">{item.description}</p>
                  </div>
                ))}
              </div>
            </motion.div>
          </section>
          
          {/* About Worthing */}
          <section className="mb-16">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
            >
              <h2 className="text-2xl font-bold text-coast-900 mb-6">About Worthing</h2>
              
              <div className="bg-coast-50 rounded-2xl p-6 md:p-8 border border-coast-100">
                <div className="md:flex gap-8">
                  <div className="md:w-2/3">
                    <p className="text-coast-800 mb-4">
                      Worthing is a historic seaside town located in West Sussex, England. With its beautiful beach, iconic pier, and vibrant town center, it offers a perfect blend of traditional seaside charm and modern amenities.
                    </p>
                    <p className="text-coast-800 mb-4">
                      The town has a rich history dating back to the Stone Age, but it rose to prominence during the Georgian and Victorian eras when it became a fashionable seaside resort. Today, Worthing continues to attract visitors with its cultural attractions, beautiful parks, and scenic coastline.
                    </p>
                    <p className="text-coast-800">
                      Notable landmarks include Worthing Pier (opened in 1862), the Dome Cinema (one of the oldest cinemas in the UK), and Worthing Museum & Art Gallery, which houses an impressive collection of costume and textiles.
                    </p>
                  </div>
                  <div className="md:w-1/3 mt-6 md:mt-0">
                    <div className="bg-white rounded-xl overflow-hidden shadow-sm">
                      <img
                        src="/lovable-uploads/d76012b7-61e0-47b2-abe9-17c18fb023c8.png"
                        alt="Worthing Pier at dusk"
                        className="w-full h-48 object-cover"
                      />
                      <div className="p-4">
                        <h4 className="font-semibold text-coast-900 mb-1">Fast Facts</h4>
                        <ul className="text-sm space-y-2">
                          <li className="flex items-start">
                            <span className="mr-2">•</span>
                            <span>Population: Approximately 110,000</span>
                          </li>
                          <li className="flex items-start">
                            <span className="mr-2">•</span>
                            <span>Location: West Sussex, South Coast of England</span>
                          </li>
                          <li className="flex items-start">
                            <span className="mr-2">•</span>
                            <span>Famous residents included Oscar Wilde and Jane Austen</span>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </section>
          
          {/* Contact */}
          <section>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              className="bg-white rounded-2xl shadow-md overflow-hidden"
            >
              <div className="p-6 md:p-8 border-b border-coast-100">
                <h2 className="text-2xl font-bold text-coast-900">Contact Us</h2>
                <p className="text-coast-700 mt-2">
                  Have questions about the game or need assistance? Reach out to our team.
                </p>
              </div>
              
              <div className="md:flex">
                <div className="md:w-1/2 p-6 md:p-8">
                  <div className="space-y-6">
                    <div className="flex items-start">
                      <div className="mr-4 mt-1">
                        <div className="w-10 h-10 rounded-full bg-coast-100 flex items-center justify-center text-coast-700">
                          <Mail className="h-5 w-5" />
                        </div>
                      </div>
                      <div>
                        <h3 className="font-semibold text-coast-900 mb-1">Email Us</h3>
                        <p className="text-coast-700 text-sm">
                          Send us an email and we&apos;ll get back to you as soon as possible.
                        </p>
                        <a href="mailto:info@worthingadventure.com" className="text-primary hover:text-primary/80 transition-colors font-medium mt-1 inline-block">
                          info@worthingadventure.com
                        </a>
                      </div>
                    </div>
                    
                    <div className="flex items-start">
                      <div className="mr-4 mt-1">
                        <div className="w-10 h-10 rounded-full bg-coast-100 flex items-center justify-center text-coast-700">
                          <Phone className="h-5 w-5" />
                        </div>
                      </div>
                      <div>
                        <h3 className="font-semibold text-coast-900 mb-1">Call Us</h3>
                        <p className="text-coast-700 text-sm">
                          Available Monday to Friday, 9am to 5pm.
                        </p>
                        <a href="tel:+441903123456" className="text-primary hover:text-primary/80 transition-colors font-medium mt-1 inline-block">
                          +44 (0) 1903 123 456
                        </a>
                      </div>
                    </div>
                    
                    <div className="flex items-start">
                      <div className="mr-4 mt-1">
                        <div className="w-10 h-10 rounded-full bg-coast-100 flex items-center justify-center text-coast-700">
                          <MessageSquare className="h-5 w-5" />
                        </div>
                      </div>
                      <div>
                        <h3 className="font-semibold text-coast-900 mb-1">Social Media</h3>
                        <p className="text-coast-700 text-sm">
                          Follow us for updates and share your adventures.
                        </p>
                        <div className="flex space-x-4 mt-2">
                          {['twitter', 'facebook', 'instagram'].map((platform) => (
                            <a
                              key={platform}
                              href={`#${platform}`}
                              className="text-coast-700 hover:text-primary transition-colors"
                            >
                              <div className="w-8 h-8 rounded-full bg-coast-50 flex items-center justify-center">
                                {platform === 'twitter' && <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723 10.032 10.032 0 01-3.127 1.195c-.897-.957-2.178-1.555-3.594-1.555-2.719 0-4.924 2.204-4.924 4.924 0 .39.044.765.126 1.124-4.097-.2-7.72-2.17-10.148-5.155a4.886 4.886 0 00-.666 2.475c0 1.71.87 3.214 2.19 4.1a4.91 4.91 0 01-2.23-.616v.06c0 2.39 1.7 4.38 3.952 4.83-.414.115-.85.174-1.297.174-.318 0-.626-.03-.931-.09.625 1.956 2.444 3.38 4.6 3.42-1.686 1.32-3.808 2.107-6.115 2.107-.398 0-.79-.023-1.175-.068 2.18 1.4 4.768 2.212 7.548 2.212 9.054 0 14-7.496 14-13.986 0-.21-.005-.423-.014-.633A10.012 10.012 0 0024 4.578z"></path></svg>}
                                {platform === 'facebook' && <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"></path></svg>}
                                {platform === 'instagram' && <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z"></path></svg>}
                              </div>
                            </a>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="md:w-1/2 p-6 md:p-8 bg-coast-50">
                  <form className="space-y-4">
                    <div>
                      <label htmlFor="name" className="block text-sm font-medium text-coast-800 mb-1">Your Name</label>
                      <input
                        type="text"
                        id="name"
                        className="w-full px-3 py-2 border border-coast-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                        placeholder="Enter your name"
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="email" className="block text-sm font-medium text-coast-800 mb-1">Email Address</label>
                      <input
                        type="email"
                        id="email"
                        className="w-full px-3 py-2 border border-coast-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                        placeholder="Enter your email"
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="message" className="block text-sm font-medium text-coast-800 mb-1">Message</label>
                      <textarea
                        id="message"
                        rows={4}
                        className="w-full px-3 py-2 border border-coast-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                        placeholder="How can we help you?"
                      ></textarea>
                    </div>
                    
                    <button type="submit" className="w-full py-2.5 bg-primary hover:bg-primary/90 text-white font-medium rounded-lg transition-colors">
                      Send Message
                    </button>
                  </form>
                </div>
              </div>
            </motion.div>
          </section>
        </div>
      </div>
    </Layout>
  );
};

export default About;
