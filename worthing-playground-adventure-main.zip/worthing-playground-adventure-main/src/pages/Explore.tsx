
import React from 'react';
import Layout from '@/components/Layout';
import Map from '@/components/Map';
import ImageGallery from '@/components/ImageGallery';
import { motion } from 'framer-motion';
import { Compass, Map as MapIcon, Info } from 'lucide-react';

const Explore = () => {
  return (
    <Layout>
      <div className="pt-20 min-h-screen">
        <div className="container mx-auto px-4 md:px-6 py-8">
          <div className="flex flex-col">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="max-w-3xl mx-auto text-center mb-12"
            >
              <div className="inline-flex items-center justify-center bg-coast-100 text-coast-800 rounded-full px-3 py-1 text-sm font-medium mb-4">
                <Compass className="mr-1 h-4 w-4" />
                Interactive Map
              </div>
              <h1 className="text-3xl md:text-4xl font-bold text-coast-900 mb-4">Explore Worthing</h1>
              <p className="text-lg text-coast-700">
                Navigate through Worthing&apos;s town center and pier. Discover historical landmarks, hidden gems, and exciting challenges.
              </p>
            </motion.div>
            
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2">
                <motion.div
                  initial={{ opacity: 0, scale: 0.98 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.5, delay: 0.2 }}
                >
                  <Map />
                </motion.div>
              </div>
              
              <div>
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.5, delay: 0.3 }}
                  className="bg-white rounded-2xl border border-coast-200 shadow-md overflow-hidden h-full"
                >
                  <div className="p-6 border-b border-coast-100">
                    <h2 className="text-xl font-semibold text-coast-900 flex items-center">
                      <Info className="w-5 h-5 mr-2 text-coast-600" />
                      How to Use the Map
                    </h2>
                  </div>
                  
                  <div className="p-6 space-y-6">
                    <div className="space-y-2">
                      <div className="flex items-center">
                        <div className="w-6 h-6 rounded-full bg-coast-500 border-2 border-white shadow-sm"></div>
                        <span className="ml-3 text-coast-800">Landmarks</span>
                      </div>
                      <p className="text-sm text-coast-600 ml-9">
                        Important locations with historical significance
                      </p>
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex items-center">
                        <div className="w-6 h-6 rounded-full bg-sand-500 border-2 border-white shadow-sm"></div>
                        <span className="ml-3 text-coast-800">Challenges</span>
                      </div>
                      <p className="text-sm text-coast-600 ml-9">
                        Interactive puzzles and tasks to complete
                      </p>
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex items-center">
                        <div className="w-6 h-6 rounded-full bg-pier-500 border-2 border-white shadow-sm"></div>
                        <span className="ml-3 text-coast-800">Shops & Refreshments</span>
                      </div>
                      <p className="text-sm text-coast-600 ml-9">
                        Places to eat, drink, or shop during your adventure
                      </p>
                    </div>
                    
                    <div className="pt-4 border-t border-coast-100">
                      <h3 className="font-medium text-coast-800 mb-3">Instructions:</h3>
                      <ol className="space-y-2 text-sm text-coast-700">
                        <li className="flex">
                          <span className="mr-2">1.</span> 
                          <span>Click on any marker to view information about the location</span>
                        </li>
                        <li className="flex">
                          <span className="mr-2">2.</span> 
                          <span>Discover new locations by exploring the town</span>
                        </li>
                        <li className="flex">
                          <span className="mr-2">3.</span> 
                          <span>Complete challenges to earn achievements</span>
                        </li>
                        <li className="flex">
                          <span className="mr-2">4.</span> 
                          <span>Track your progress in the challenges section</span>
                        </li>
                      </ol>
                    </div>
                  </div>
                  
                  <div className="p-6 bg-coast-50 border-t border-coast-100">
                    <button className="w-full py-3 bg-coast-600 hover:bg-coast-700 transition-colors rounded-lg text-white font-medium flex items-center justify-center">
                      <MapIcon className="w-5 h-5 mr-2" />
                      View Full Screen Map
                    </button>
                  </div>
                </motion.div>
              </div>
            </div>
            
            {/* Recently Discovered Locations - Now using ImageGallery component with fixed image paths */}
            <div className="mt-12">
              <h2 className="text-2xl font-bold text-coast-900 mb-6">Recently Discovered</h2>
              
              <ImageGallery 
                title="" 
                images={[
                  {
                    src: '/lovable-uploads/d76012b7-61e0-47b2-abe9-17c18fb023c8.png',
                    alt: "Worthing Pier",
                    caption: "Worthing's beloved pier stretches out into the English Channel. Take a stroll to enjoy sea views and visit the Southern Pavilion."
                  },
                  {
                    src: '/lovable-uploads/94b1cce7-40df-4c0e-93ea-90312eea5154.png',
                    alt: "Pavilion Theatre",
                    caption: "An elegant Edwardian theatre hosting a variety of shows and performances throughout the year."
                  },
                  {
                    src: '/lovable-uploads/5ea33c28-c3db-4cf8-8d67-09f71e73ac7e.png',
                    alt: "Worthing Beach",
                    caption: "A beautiful pebble beach with stunning views across the English Channel."
                  }
                ]}
              />
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Explore;
