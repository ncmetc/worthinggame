
import React from 'react';
import { motion } from 'framer-motion';
import { Award } from 'lucide-react';

interface PageHeaderProps {
  title: string;
  subtitle: string;
  description: string;
}

const PageHeader: React.FC<PageHeaderProps> = ({ title, subtitle, description }) => {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="max-w-3xl mx-auto text-center mb-12"
    >
      <div className="inline-flex items-center justify-center bg-sand-100 text-sand-800 rounded-full px-3 py-1 text-sm font-medium mb-4">
        <Award className="mr-1 h-4 w-4" />
        {subtitle}
      </div>
      <h1 className="text-3xl md:text-4xl font-bold text-coast-900 mb-4">{title}</h1>
      <p className="text-lg text-coast-700">
        {description}
      </p>
    </motion.div>
  );
};

export default PageHeader;
