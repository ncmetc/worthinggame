
import React from 'react';
import { motion } from 'framer-motion';
import { Award, MapPin, Clock, ArrowRight } from 'lucide-react';
import { cn } from '@/lib/utils';

interface ChallengeProps {
  id: string;
  title: string;
  description: string;
  location: string;
  difficulty: 'easy' | 'medium' | 'hard';
  duration: string;
  image: string;
  completed: boolean;
  progress: number;
}

export const Challenge: React.FC<ChallengeProps> = ({
  id,
  title,
  description,
  location,
  difficulty,
  duration,
  image,
  completed,
  progress,
}) => {
  // Map locations to specific images with fixed paths
  const getLocationImage = () => {
    switch (location) {
      case 'Worthing Pier':
        return '/lovable-uploads/d76012b7-61e0-47b2-abe9-17c18fb023c8.png';
      case 'Beach':
      case 'Seafront':
      case 'Worthing Beach':
        return '/lovable-uploads/5ea33c28-c3db-4cf8-8d67-09f71e73ac7e.png';
      case 'Pavilion Theatre':
        return '/lovable-uploads/94b1cce7-40df-4c0e-93ea-90312eea5154.png';
      case 'The Dome Cinema':
        return 'https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&q=80';
      case 'Worthing Museum':
        return 'https://images.unsplash.com/photo-1518998053901-5348d3961a04?auto=format&fit=crop&q=80';
      case 'Town Hall':
        return 'https://images.unsplash.com/photo-1577760258779-e787a1633c18?auto=format&fit=crop&q=80';
      case 'Various Locations':
        return 'https://images.unsplash.com/photo-1519331379826-f10be5486c6f?auto=format&fit=crop&q=80';
      default:
        return image || 'https://images.unsplash.com/photo-1465146344425-f00d5f5c8f07?auto=format&fit=crop&q=80';
    }
  };
    
  const difficultyColor = {
    easy: 'bg-green-100 text-green-800',
    medium: 'bg-amber-100 text-amber-800',
    hard: 'bg-red-100 text-red-800',
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="challenge-card overflow-hidden h-full flex flex-col"
    >
      <div className="relative h-48 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent z-10"></div>
        <img
          src={getLocationImage()}
          alt={title}
          className="w-full h-full object-cover transition-transform duration-1000 hover:scale-110"
          onError={(e) => {
            e.currentTarget.src = 'https://images.unsplash.com/photo-1465146344425-f00d5f5c8f07?auto=format&fit=crop&q=80';
          }}
        />
        <div className="absolute bottom-4 left-4 z-20 flex items-center space-x-2">
          <div className="flex items-center space-x-1">
            <MapPin className="w-4 h-4 text-white" />
            <span className="text-xs text-white">{location}</span>
          </div>
        </div>
        {completed && (
          <div className="absolute top-4 right-4 z-20 bg-white/90 backdrop-blur-sm rounded-full p-1">
            <Award className="w-5 h-5 text-coast-600" />
          </div>
        )}
      </div>
      
      <div className="flex-grow flex flex-col p-4">
        <div className="flex items-center justify-between mb-2">
          <span
            className={cn(
              'text-xs px-2 py-1 rounded-full',
              difficultyColor[difficulty]
            )}
          >
            {difficulty.charAt(0).toUpperCase() + difficulty.slice(1)}
          </span>
          <div className="flex items-center text-xs text-gray-500">
            <Clock className="w-3 h-3 mr-1" />
            {duration}
          </div>
        </div>
        
        <h3 className="text-lg font-semibold mb-2 text-coast-900">{title}</h3>
        <p className="text-sm text-coast-700 mb-4 flex-grow">{description}</p>
        
        {!completed && (
          <div className="mb-3">
            <div className="h-1.5 w-full bg-gray-100 rounded-full overflow-hidden">
              <div
                className="h-full bg-coast-500 rounded-full transition-all duration-1000"
                style={{ width: `${progress}%` }}
              ></div>
            </div>
            <div className="flex justify-end mt-1">
              <span className="text-xs text-gray-500">{progress}% complete</span>
            </div>
          </div>
        )}
        
        <button
          className={cn(
            "mt-auto py-2 px-4 rounded-lg flex items-center justify-center transition-all duration-300",
            completed
              ? "bg-coast-50 text-coast-600 hover:bg-coast-100"
              : "bg-coast-600 text-white hover:bg-coast-700"
          )}
        >
          <span>{completed ? "View Completed" : "Continue Challenge"}</span>
          <ArrowRight className="ml-2 w-4 h-4" />
        </button>
      </div>
    </motion.div>
  );
};

export default Challenge;
