
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { MapPin, AlertCircle, Navigation, X } from 'lucide-react';

interface Location {
  id: string;
  name: string;
  description: string;
  x: number;
  y: number;
  type: 'landmark' | 'challenge' | 'shop';
  discovered: boolean;
  image?: string;
}

const locations: Location[] = [
  {
    id: 'pier',
    name: 'Worthing Pier',
    description: 'A Grade II listed pleasure pier in Worthing, West Sussex, England. Opened in 1862, the pier has been transformed multiple times throughout its history.',
    x: 75,
    y: 30,
    type: 'landmark',
    discovered: true,
    image: '/lovable-uploads/d76012b7-61e0-47b2-abe9-17c18fb023c8.png'
  },
  {
    id: 'pavilion',
    name: 'Pavilion Theatre',
    description: 'A beautiful Edwardian theatre on the promenade, hosting various performances and shows.',
    x: 60,
    y: 35,
    type: 'landmark',
    discovered: true,
    image: '/lovable-uploads/94b1cce7-40df-4c0e-93ea-90312eea5154.png'
  },
  {
    id: 'town-hall',
    name: 'Town Hall',
    description: 'A historic building in the center of Worthing. Built in 1933, it serves as the administrative center.',
    x: 50,
    y: 50,
    type: 'landmark',
    discovered: false,
  },
  {
    id: 'museum',
    name: 'Worthing Museum & Art Gallery',
    description: 'Discover the rich history of Worthing and enjoy fascinating art exhibitions.',
    x: 40,
    y: 55,
    type: 'challenge',
    discovered: false,
  },
  {
    id: 'beach',
    name: 'Worthing Beach',
    description: 'A beautiful pebble beach with stunning views across the English Channel. Popular for swimming, water sports, and relaxation.',
    x: 85,
    y: 40,
    type: 'shop',
    discovered: true,
    image: '/lovable-uploads/5ea33c28-c3db-4cf8-8d67-09f71e73ac7e.png'
  },
  {
    id: 'dome',
    name: 'The Dome Cinema',
    description: 'One of the oldest working cinemas in the UK, with beautiful Edwardian architecture.',
    x: 65,
    y: 45,
    type: 'challenge',
    discovered: false,
  },
];

export const Map: React.FC = () => {
  const [selectedLocation, setSelectedLocation] = useState<Location | null>(null);
  const [isInfoOpen, setIsInfoOpen] = useState(false);

  const handleLocationClick = (location: Location) => {
    setSelectedLocation(location);
    setIsInfoOpen(true);
  };

  const closeInfo = () => {
    setIsInfoOpen(false);
    setTimeout(() => setSelectedLocation(null), 300);
  };

  const getMarkerColor = (type: Location['type']) => {
    switch (type) {
      case 'landmark': return 'bg-coast-500';
      case 'challenge': return 'bg-sand-500';
      case 'shop': return 'bg-pier-500';
      default: return 'bg-primary';
    }
  };

  return (
    <div className="relative w-full h-full">
      <div className="relative w-full overflow-hidden rounded-2xl border border-coast-200 shadow-lg" style={{ aspectRatio: '4/3' }}>
        {/* Map image - Using the satellite map image */}
        <div className="relative w-full h-full">
          <img 
            src="/lovable-uploads/7f3090d4-a540-4918-900d-c28c81fefe46.png" 
            alt="Worthing map view" 
            className="absolute inset-0 w-full h-full object-cover"
          />
          
          <div className="absolute inset-0 bg-gradient-to-b from-coast-100/10 to-coast-300/10"></div>
          
          {/* Grid lines */}
          <div className="absolute inset-0" style={{ 
            backgroundImage: 'linear-gradient(to right, rgba(255,255,255,0.1) 1px, transparent 1px), linear-gradient(to bottom, rgba(255,255,255,0.1) 1px, transparent 1px)',
            backgroundSize: '5% 5%' 
          }}></div>
          
          {/* Location Markers */}
          {locations.map((location) => (
            <motion.button
              key={location.id}
              className={`absolute w-6 h-6 rounded-full border-2 border-white shadow-md flex items-center justify-center transition-transform duration-300 ${getMarkerColor(location.type)} ${location.discovered ? 'opacity-100' : 'opacity-60'}`}
              style={{ left: `${location.x}%`, top: `${location.y}%` }}
              whileHover={{ scale: 1.2 }}
              whileTap={{ scale: 0.9 }}
              onClick={() => handleLocationClick(location)}
            >
              {!location.discovered && <AlertCircle className="w-3 h-3 text-white" />}
            </motion.button>
          ))}
          
          {/* Compass */}
          <div className="absolute bottom-4 right-4 w-12 h-12 rounded-full bg-white/80 backdrop-blur-sm shadow-md flex items-center justify-center">
            <Navigation className="w-8 h-8 text-coast-800" />
          </div>
        </div>
      </div>
      
      {/* Location Info Panel */}
      <motion.div 
        className="absolute bottom-0 left-0 right-0 bg-white/90 backdrop-blur-md rounded-t-2xl shadow-lg border border-coast-200 p-6 max-h-[50%] overflow-y-auto"
        initial={{ y: '100%' }}
        animate={{ y: isInfoOpen ? '0%' : '100%' }}
        transition={{ type: 'spring', damping: 25, stiffness: 200 }}
      >
        {selectedLocation && (
          <div className="space-y-4">
            <div className="flex justify-between items-start">
              <div>
                <span className="inline-block px-2 py-1 text-xs rounded-full bg-coast-100 text-coast-800 mb-2">
                  {selectedLocation.type.charAt(0).toUpperCase() + selectedLocation.type.slice(1)}
                </span>
                <h3 className="text-xl font-semibold text-coast-900">{selectedLocation.name}</h3>
              </div>
              <button 
                onClick={closeInfo}
                className="w-8 h-8 flex items-center justify-center rounded-full bg-coast-100 hover:bg-coast-200 transition-colors"
              >
                <X className="w-4 h-4 text-coast-800" />
              </button>
            </div>
            
            {selectedLocation.image && (
              <div className="rounded-lg overflow-hidden h-32 mb-2">
                <img 
                  src={selectedLocation.image} 
                  alt={selectedLocation.name} 
                  className="w-full h-full object-cover"
                />
              </div>
            )}
            
            <p className="text-coast-700">{selectedLocation.description}</p>
            
            {selectedLocation.discovered ? (
              <button className="w-full py-3 mt-4 bg-primary rounded-lg text-white font-medium hover:bg-primary/90 transition-colors">
                Visit Location
              </button>
            ) : (
              <button className="w-full py-3 mt-4 bg-sand-500 rounded-lg text-white font-medium hover:bg-sand-600 transition-colors">
                Discover This Location
              </button>
            )}
          </div>
        )}
      </motion.div>
    </div>
  );
};

export default Map;
