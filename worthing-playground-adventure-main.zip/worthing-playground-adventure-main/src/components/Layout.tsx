
import React from 'react';
import { NavBar } from './NavBar';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <NavBar />
      <main className="flex-grow">
        <div className="animate-fade-in">
          {children}
        </div>
      </main>
      <footer className="py-6 bg-coast-50 border-t border-coast-100">
        <div className="container mx-auto px-4 md:px-6">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-sm text-coast-800">© 2023 Worthing Adventure Game. All rights reserved.</p>
            <div className="flex items-center space-x-4 mt-4 md:mt-0">
              <a href="#" className="text-sm text-coast-700 hover-link">Terms</a>
              <a href="#" className="text-sm text-coast-700 hover-link">Privacy</a>
              <a href="#" className="text-sm text-coast-700 hover-link">Contact</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Layout;
