
import React from 'react';
import Challenge from './Challenge';
import { Search } from 'lucide-react';

interface ChallengeGridProps {
  challenges: any[];
  searchTerm: string;
  setSearchTerm: (term: string) => void;
  filter: string;
  setFilter: (filter: string) => void;
}

const ChallengeGrid: React.FC<ChallengeGridProps> = ({
  challenges,
  searchTerm,
  setSearchTerm,
  filter,
  setFilter,
}) => {
  if (challenges.length === 0) {
    return (
      <div className="text-center py-12">
        <div className="flex justify-center mb-4">
          <div className="rounded-full bg-coast-50 p-3">
            <Search className="h-8 w-8 text-coast-500" />
          </div>
        </div>
        <h3 className="text-xl font-semibold text-coast-900 mb-2">No challenges found</h3>
        <p className="text-coast-700">
          Try adjusting your search or filter to find what you're looking for.
        </p>
        <button
          className="mt-4 px-4 py-2 bg-coast-100 text-coast-800 rounded-lg hover:bg-coast-200 transition-colors"
          onClick={() => {
            setSearchTerm('');
            setFilter('all');
          }}
        >
          Reset filters
        </button>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {challenges.map((challenge) => (
        <Challenge key={challenge.id} {...challenge} />
      ))}
    </div>
  );
};

export default ChallengeGrid;
