
import React from 'react';
import { Award } from 'lucide-react';

interface ProgressSectionProps {
  totalChallenges: number;
  completedChallenges: number;
}

const ProgressSection: React.FC<ProgressSectionProps> = ({
  totalChallenges,
  completedChallenges,
}) => {
  const progressPercentage = Math.round((completedChallenges / totalChallenges) * 100);

  return (
    <div className="mt-16 bg-sand-50 rounded-xl p-6 md:p-8 border border-sand-100">
      <div className="flex flex-col md:flex-row items-center gap-6 md:gap-8">
        <div className="w-16 h-16 rounded-full bg-white shadow-sm flex items-center justify-center">
          <Award className="h-8 w-8 text-sand-500" />
        </div>
        <div className="flex-grow text-center md:text-left">
          <h3 className="text-xl font-semibold text-coast-900 mb-2">Challenge Progress</h3>
          <p className="text-coast-700">
            You've completed {completedChallenges} of {totalChallenges} challenges. Keep exploring to discover more!
          </p>
        </div>
        <div className="w-full md:w-auto">
          <div className="w-full md:w-48 h-3 bg-white rounded-full overflow-hidden">
            <div
              className="h-full bg-sand-500 rounded-full"
              style={{ width: `${progressPercentage}%` }}
            ></div>
          </div>
          <div className="mt-2 text-right text-sm text-coast-700">
            {progressPercentage}% Complete
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProgressSection;
