
import React from 'react';
import { Filter, Search, X } from 'lucide-react';

interface SearchAndFilterProps {
  searchTerm: string;
  setSearchTerm: (term: string) => void;
  filter: string;
  setFilter: (filter: string) => void;
  isFilterOpen: boolean;
  setIsFilterOpen: (open: boolean) => void;
}

const SearchAndFilter: React.FC<SearchAndFilterProps> = ({
  searchTerm,
  setSearchTerm,
  filter,
  setFilter,
  isFilterOpen,
  setIsFilterOpen,
}) => {
  const filterOptions = [
    { id: 'all', name: 'All Challenges' },
    { id: 'completed', name: 'Completed' },
    { id: 'in-progress', name: 'In Progress' },
    { id: 'not-started', name: 'Not Started' },
  ];

  return (
    <div className="mb-8 flex flex-col sm:flex-row gap-4">
      <div className="relative flex-grow">
        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
          <Search className="h-5 w-5 text-gray-400" />
        </div>
        <input
          type="text"
          placeholder="Search challenges..."
          className="w-full pl-10 pr-4 py-2.5 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-coast-500 focus:border-transparent"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
        {searchTerm && (
          <button
            className="absolute inset-y-0 right-0 pr-3 flex items-center"
            onClick={() => setSearchTerm('')}
          >
            <X className="h-4 w-4 text-gray-400 hover:text-gray-600" />
          </button>
        )}
      </div>
      
      <div className="relative">
        <button
          className="px-4 py-2.5 bg-white border border-gray-300 rounded-lg flex items-center space-x-2 hover:bg-gray-50"
          onClick={() => setIsFilterOpen(!isFilterOpen)}
        >
          <Filter className="h-5 w-5 text-gray-500" />
          <span>Filter</span>
        </button>
        
        {isFilterOpen && (
          <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg z-50 border border-gray-200 overflow-hidden">
            <div className="py-1">
              {filterOptions.map((option) => (
                <button
                  key={option.id}
                  className={`w-full text-left px-4 py-2 text-sm ${
                    filter === option.id ? 'bg-coast-50 text-coast-900' : 'text-gray-800 hover:bg-gray-100'
                  }`}
                  onClick={() => {
                    setFilter(option.id);
                    setIsFilterOpen(false);
                  }}
                >
                  {option.name}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default SearchAndFilter;
