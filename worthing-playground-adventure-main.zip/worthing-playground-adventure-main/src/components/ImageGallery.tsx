
import React from 'react';
import { motion } from 'framer-motion';

interface ImageGalleryProps {
  images: {
    src: string;
    alt: string;
    caption?: string;
  }[];
  title?: string;
}

const ImageGallery: React.FC<ImageGalleryProps> = ({ images, title = "Worthing Gallery" }) => {
  // Default gallery images including uploaded images
  const defaultImages = [
    {
      src: '/lovable-uploads/d76012b7-61e0-47b2-abe9-17c18fb023c8.png',
      alt: "Worthing Pier",
      caption: "Historic Worthing Pier - The heart of Worthing's seafront"
    },
    {
      src: '/lovable-uploads/5ea33c28-c3db-4cf8-8d67-09f71e73ac7e.png',
      alt: "Worthing Beach",
      caption: "The pebble beach at Worthing - Perfect for a seaside stroll"
    },
    {
      src: '/lovable-uploads/94b1cce7-40df-4c0e-93ea-90312eea5154.png',
      alt: "Worthing Seafront",
      caption: "Beautiful views across the English Channel from Worthing Beach"
    },
    {
      src: 'https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&q=80',
      alt: "The Dome Cinema",
      caption: "The historic Dome Cinema - one of the oldest working cinemas in the UK"
    },
    {
      src: 'https://images.unsplash.com/photo-1577760258779-e787a1633c18?auto=format&fit=crop&q=80',
      alt: "Worthing Town Hall",
      caption: "The magnificent Worthing Town Hall - an impressive architectural landmark"
    },
    {
      src: 'https://images.unsplash.com/photo-1500375592092-40eb2168fd21?auto=format&fit=crop&q=80',
      alt: "Worthing Pebble Beach",
      caption: "The distinctive pebble beach that stretches along Worthing's coastline"
    },
  ];
  
  // Combine any provided images with default images
  const displayImages = images.length > 0 ? images : defaultImages;
  
  return (
    <div className="mt-12">
      <h2 className="text-2xl font-bold text-coast-800 mb-6">{title}</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {displayImages.map((image, index) => (
          <motion.div
            key={index}
            className="overflow-hidden rounded-xl shadow-md bg-white border border-coast-100"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
          >
            <div className="relative">
              <img 
                src={image.src} 
                alt={image.alt} 
                className="w-full h-56 object-cover transition-transform duration-500 hover:scale-105"
                onError={(e) => {
                  e.currentTarget.src = 'https://images.unsplash.com/photo-1465146344425-f00d5f5c8f07?auto=format&fit=crop&q=80';
                }}
              />
              {image.caption && (
                <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-night-900/80 to-transparent p-4">
                  <p className="text-white text-sm">{image.caption}</p>
                </div>
              )}
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default ImageGallery;
